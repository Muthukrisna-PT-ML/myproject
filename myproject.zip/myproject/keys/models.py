# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
#from django.db import models

class File(models.Model):
    crt_file = models.FileField(blank=False, null=False)
    key_file = models.FileField(blank=False, null=False)
