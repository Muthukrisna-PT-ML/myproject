import os

def move():
    os.system('cp /etc/ssl/certs/localhost.crt /home/muthukrisna/backup')
    os.system('cp /etc/ssl/private/localhost.key /home/muthukrisna/backup')

