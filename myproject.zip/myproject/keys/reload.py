import os

def reloads():
    os.system('cp /etc/ssl/certs/*.crt /home/muthukrisna/backup')
    os.system('cp /etc/ssl/private/*.key /home/muthukrisna/backup')
    os.system('mv /home/muthukrisna/myproject/media/*.crt localhost.crt')
    os.system('mv /home/muthukrisna/myproject/media/*.key localhost.key')
    os.system('mv /home/muthukrisna/myproject/media/localhost.crt /etc/ssl/certs')
    os.system('mv /home/muthukrisna/myproject/media/localhost.key /etc/ssl/private')
    os.system('rm -f /home/muthukrisna/myproject/media/*')
    os.system('systemctl reload apache2')
