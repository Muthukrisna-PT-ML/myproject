from django.conf.urls import url
#from . import views
from .views import FileView
urlpatterns = [
        url(r'^upload/', FileView.as_view(), name='upload'),
]

